// Define arrays to store information about registered pets
let pets = [];
let dogCount = 0;
let catCount = 0;
let otherCount = 0;

// Function to display the registered pets count and type counts
function displayPetsCount() {
    const totalPetsCount = pets.length;
    const petsCountElement = document.getElementById("pets-count");
    const dogCountElement = document.getElementById("dog-count");
    const catCountElement = document.getElementById("cat-count");
    const otherCountElement = document.getElementById("other-count");

    if (petsCountElement) {
        petsCountElement.textContent = totalPetsCount;
    }

    if (dogCountElement) {
        dogCountElement.textContent = dogCount;
    }

    if (catCountElement) {
        catCountElement.textContent = catCount;
    }

    if (otherCountElement) {
        otherCountElement.textContent = otherCount;
    }
}

// Function to display pet names
function displayPetNames() {
    const petListElement = document.getElementById("pet-list");
    if (petListElement) {
        petListElement.innerHTML = ''; // Clear previous content

        pets.forEach(pet => {
            const listItem = document.createElement("li");
            listItem.textContent = pet.name;
            petListElement.appendChild(listItem);
        });
    }
}

// Function to register a new pet
function registerPet(event) {
    event.preventDefault(); // Prevent form submission

    // Get values from the form
    const name = document.getElementById("pet-name").value;
    const breed = document.getElementById("pet-breed").value;
    const type = document.getElementById("pet-type").value;
    const gender = document.getElementById("pet-gender").value;
    const age = parseInt(document.getElementById("pet-age").value);
    const service = document.getElementById("pet-service").value;

    // Create a new pet object
    const newPet = {
        name: name,
        age: age,
        gender: gender,
        service: service,
        breed: breed,
        type: type 
    };

    // Add the new pet to the pets array
    pets.push(newPet);

    // Update type count based on the pet type
    if (type === "Dog") {
        dogCount++;
    } else if (type === "Cat") {
        catCount++;
    } else {
        otherCount++;
    }

    // Update display of registered pets count and pet names
    displayPetsCount();
    displayPetNames();

    // Reset the form
    event.target.reset();
}


const petForm = document.getElementById("registration-form");
if (petForm) {
    petForm.addEventListener("submit", registerPet);
}


displayPetsCount();
displayPetNames();
