// Define an array to store information about registered pets
let pets = [
    {
        name: "Max",
        age: 3,
        gender: "Male",
        service: "Grooming",
        breed: "Labrador"
    },
    {
        name: "Bella",
        age: 2,
        gender: "Female",
        service: "Bathing",
        breed: "Poodle"
    },
    {
        name: "Charlie",
        age: 5,
        gender: "Male",
        service: "Trimming",
        breed: "Shih Tzu"
    }
];

// Function to display the registered pets count
function displayPetsCount() {
    const petsCount = pets.length;
    const petsCountElement = document.getElementById("pets-count");
    petsCountElement.textContent = petsCount;
}

// Function to display pet names
function displayPetNames() {
    const petListElement = document.getElementById("pet-list");
    petListElement.innerHTML = ''; // Clear previous content

    pets.forEach(pet => {
        const listItem = document.createElement("li");
        listItem.textContent = pet.name;
        petListElement.appendChild(listItem);
    });
}

// Function to register a new pet
function registerPet(event) {
    event.preventDefault(); // Prevent form submission

    // Get values from the form
    const name = document.getElementById("pet-name").value;
    const breed = document.getElementById("pet-breed").value;
    const gender = document.getElementById("pet-gender").value;
    const age = parseInt(document.getElementById("pet-age").value);
    const service = document.getElementById("pet-service").value;

    // Create a new pet object
    const newPet = {
        name: name,
        age: age,
        gender: gender,
        service: service,
        breed: breed
    };

    // Add the new pet to the pets array
    pets.push(newPet);

    // Update display of registered pets count and pet names
    displayPetsCount();
    displayPetNames();

    // Reset the form
    event.target.reset();
}

// Add event listener to the pet registration form
const petForm = document.getElementById("pet-form");
petForm.addEventListener("submit", registerPet);

// Initial display of registered pets count and pet names
displayPetsCount();
displayPetNames();
