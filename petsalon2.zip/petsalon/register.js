
let pets = [];


function displayPetsCount() {
    const petsCount = pets.length;
    const petsCountElement = document.getElementById("pets-count");
    if (petsCountElement) {
        petsCountElement.textContent = petsCount;
    }
}

// Function to display pet names
function displayPetNames() {
    const petListElement = document.getElementById("pet-list");
    if (petListElement) {
        petListElement.innerHTML = ''; 

        pets.forEach(pet => {
            const listItem = document.createElement("li");
            listItem.textContent = pet.name;
            petListElement.appendChild(listItem);
        });
    }
}

// Function to register a new pet
function registerPet(event) {
    event.preventDefault(); 

    // Get values from the form
    const name = document.getElementById("pet-name").value;
    const breed = document.getElementById("pet-breed").value;
    const gender = document.getElementById("pet-gender").value;
    const age = parseInt(document.getElementById("pet-age").value);
    const service = document.getElementById("pet-service").value;

    // Create a new pet object
    const newPet = {
        name: name,
        age: age,
        gender: gender,
        service: service,
        breed: breed
    };

    // Add the new pet to the pets array
    pets.push(newPet);

    // Update display of registered pets count and pet names
    displayPetsCount();
    displayPetNames();

    // Reset the form
    event.target.reset();
}


const petForm = document.getElementById("registration-form");
if (petForm) {
    petForm.addEventListener("submit", registerPet);
}


displayPetsCount();
displayPetNames();

